<?php

/* {$id} */

?>
<p class="animated <?php echo $item->get('effect'); ?>" style="animation-delay: 0.5s; -webkit-animation-delay: 0.5s; animation-duration: 0.7s;">
    <img src="<?php echo $item->get('resized_image_url'); ?>" />
</p>