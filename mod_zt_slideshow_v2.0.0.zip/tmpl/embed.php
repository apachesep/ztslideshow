<?php

/* {$id} */
?>
<div class="ps-<?php echo $item->get('position'); ?> animated <?php echo $item->get('effect'); ?>">
    <?php echo $item->getEmbed(); ?>
</div>