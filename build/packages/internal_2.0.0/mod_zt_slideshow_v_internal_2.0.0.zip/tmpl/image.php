<?php

/**
 * @name        ZT SlideShow
 * @package     Joomla
 * @subpackage  Module
 * @author      ZooTemplate
 * @link        http://www.zootemplate.com
 * @copyright   ZooTemplate.com
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * 
 * @version     internal_2.0.0
 * @builddate   2015-04-10T02:51:36+00:00
 */
defined('_JEXEC') or die('Restricted access');

?>
<p class="animated <?php echo $item->get('effect'); ?>" style="animation-delay: 0.5s; -webkit-animation-delay: 0.5s; animation-duration: 0.7s;">
    <img src="<?php echo $item->get('resized_image_url'); ?>" />
</p>