<?php

/**
 * @name        ZT SlideShow
 * @package     Joomla
 * @subpackage  Module
 * @author      ZooTemplate
 * @link        http://www.zootemplate.com
 * @copyright   ZooTemplate.com
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * 
 * @version     internal_2.0.0
 * @builddate   2015-04-10T02:51:36+00:00
 */
defined('_JEXEC') or die('Restricted access');
?>
<div class="ps-<?php echo $item->get('position'); ?> animated <?php echo $item->get('effect'); ?>">
    <?php echo $item->getEmbed(); ?>
</div>