<?php

/**
 * @name        ZT SlideShow
 * @package     Joomla
 * @subpackage  Module
 * @author      ZooTemplate
 * @link        http://www.zootemplate.com
 * @copyright   ZooTemplate.com
 * @license     GNU General Public License version 2 or later; see LICENSE.txt
 * 
 * @version     internal_2.0.0
 * @builddate   2015-04-10T02:51:36+00:00
 */
defined('_JEXEC') or die('Restricted access');

require_once __DIR__ . '/bootstrap.php';

$slides = json_decode($params->get('slides'));

$slides = ZtSlideshowHelperHelper::prepare($slides, $params);

require JModuleHelper::getLayoutPath('mod_zt_slideshow', $params->get('layout', 'default'));
